module.exports = {
  apps: [
    {
      name: 'abarrotes-backend',
      script: './backend/server.js',
      instances: 4,
      exec_mode: 'cluster',
      env: {
        NODE_ENV: 'production',
        PORT: 5000
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 5000
      },
      max_memory_restart: '1G',

      error_file: '/var/log/abarrotes/error.log',
      out_file: '/var/log/abarrotes/out.log',
      log_file: '/var/log/abarrotes/combined.log',
      time: true,
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s',
      
      listen_timeout: 5000,
      kill_timeout: 5000,
      
      watch: false,
      ignore_watch: ['node_modules', 'logs', '*.log'],
      
      cron_restart: '0 4 * * *',
      
      merge_logs: true,
      
      source_map_support: true
    },
    
    // CONFIGURACIÓN STAGING
    {
      name: 'abarrotes-backend-staging',
      script: './backend/server.js',
      instances: 2,
      exec_mode: 'cluster',
      env: {
        NODE_ENV: 'staging',
        PORT: 5001
      },
      env_staging: {
        NODE_ENV: 'staging',
        PORT: 5001
      },
      max_memory_restart: '512M',

      error_file: '/var/log/abarrotes-staging/error.log',
      out_file: '/var/log/abarrotes-staging/out.log',
      log_file: '/var/log/abarrotes-staging/combined.log',
      time: true,
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s',
      
      listen_timeout: 5000,
      kill_timeout: 5000,
      
      watch: false,
      ignore_watch: ['node_modules', 'logs', '*.log'],

      merge_logs: true,

      source_map_support: true
    },

    // CONFIGURACIÓN DESARROLLO 
    {
      name: 'abarrotes-backend-dev',
      script: './backend/server.js',
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'development',
        PORT: 5002
      },
      env_development: {
        NODE_ENV: 'development',
        PORT: 5002
      },
      watch: true,
      ignore_watch: [
        'node_modules',
        'logs',
        '*.log',
        '.git'
      ],
      watch_options: {
        followSymlinks: false,
        usePolling: false
      },

      error_file: './logs/dev-error.log',
      out_file: './logs/dev-out.log',
      time: true,
      autorestart: true,
      max_restarts: 5
    }
  ],

  // CONFIGURACIÓN DE DEPLOYMENT
  deploy: {
    production: {
      user: 'deploy',
      host: 'abarrotes.com',
      ref: 'origin/main',
      repo: 'git@github.com:tu-usuario/abarrotes.git',
      path: '/var/www/abarrotes-production',
      'post-deploy': 'cd backend && npm install --production && pm2 reload ecosystem.config.js --env production',
      env: {
        NODE_ENV: 'production'
      }
    },
    staging: {
      user: 'deploy',
      host: 'staging.abarrotes.com',
      ref: 'origin/develop',
      repo: 'git@github.com:tu-usuario/abarrotes.git',
      path: '/var/www/abarrotes-staging',
      'post-deploy': 'cd backend && npm install && pm2 reload ecosystem.config.js --env staging',
      env: {
        NODE_ENV: 'staging'
      }
    }
  }
};
