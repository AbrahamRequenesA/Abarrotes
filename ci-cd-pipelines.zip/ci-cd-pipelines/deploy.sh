#!/bin/bash

set -e 

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' 

ENVIRONMENT=$1
COMPONENT=$2
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo -e "ℹ $1"
}

show_usage() {
    echo "Uso: $0 [staging|production] [backend|frontend|all]"
    echo ""
    echo "Ejemplos:"
    echo "  $0 staging all          # Deploy completo a staging"
    echo "  $0 production backend   # Deploy solo backend a producción"
    echo "  $0 staging frontend     # Deploy solo frontend a staging"
    exit 1
}

check_environment() {
    if [ -z "$ENVIRONMENT" ] || [ -z "$COMPONENT" ]; then
        show_usage
    fi

    if [ "$ENVIRONMENT" != "staging" ] && [ "$ENVIRONMENT" != "production" ]; then
        print_error "Ambiente inválido. Usa 'staging' o 'production'"
        exit 1
    fi

    if [ "$COMPONENT" != "backend" ] && [ "$COMPONENT" != "frontend" ] && [ "$COMPONENT" != "all" ]; then
        print_error "Componente inválido. Usa 'backend', 'frontend' o 'all'"
        exit 1
    fi
}

load_env_file() {
    if [ "$ENVIRONMENT" = "staging" ]; then
        ENV_FILE=".env.staging"
    else
        ENV_FILE=".env.production"
    fi

    if [ ! -f "$ENV_FILE" ]; then
        print_error "Archivo $ENV_FILE no encontrado"
        exit 1
    fi

    print_info "Cargando variables de $ENV_FILE"
    source "$ENV_FILE"
}

create_backup() {
    print_info "Creando backup..."
    
    BACKUP_DIR="./backups"
    mkdir -p "$BACKUP_DIR"

    tar -czf "$BACKUP_DIR/backup_code_${TIMESTAMP}.tar.gz" \
        backend/ frontend/ \
        --exclude=backend/node_modules \
        --exclude=frontend/node_modules \
        --exclude=frontend/build 2>/dev/null || true
    
    print_success "Backup creado: backup_code_${TIMESTAMP}.tar.gz"
}

deploy_backend() {
    print_info "Desplegando Backend..."
    
    cd backend

    print_info "Instalando dependencias..."
    npm install --production

    if [ ! -f ".env" ]; then
        print_warning "Creando archivo .env para backend..."
        cp ../.env.example .env
    fi

    print_info "Reiniciando servicio con PM2..."
    if pm2 describe abarrotes-backend-$ENVIRONMENT > /dev/null 2>&1; then
        pm2 restart abarrotes-backend-$ENVIRONMENT
        print_success "Backend reiniciado"
    else
        pm2 start server.js --name abarrotes-backend-$ENVIRONMENT
        print_success "Backend iniciado"
    fi
    
    pm2 save
    
    cd ..
    print_success "Backend desplegado exitosamente"
}

deploy_frontend() {
    print_info "Desplegando Frontend..."
    
    cd frontend

    print_info "Instalando dependencias..."
    npm install

    print_info "Compilando frontend..."
    npm run build

    if [ -n "$WEBSERVER_DIR" ]; then
        print_info "Copiando archivos al servidor web..."
        rm -rf "$WEBSERVER_DIR"/*
        cp -r build/* "$WEBSERVER_DIR"/
        print_success "Archivos copiados a $WEBSERVER_DIR"
    else
        print_warning "WEBSERVER_DIR no configurado en $ENV_FILE"
    fi
    
    cd ..
    print_success "Frontend desplegado exitosamente"
}

run_database_migrations() {
    print_info "Verificando migraciones de base de datos..."
    
    if [ -f "database.sql" ]; then
        print_warning "Se encontró database.sql. ¿Aplicar cambios? (y/n)"
        read -r response
        if [ "$response" = "y" ]; then
            mysql -h "$DB_HOST" -u "$DB_USER" -p"$DB_PASSWORD" "$DB_NAME" < database.sql
            print_success "Migraciones aplicadas"
        else
            print_info "Migraciones omitidas"
        fi
    else
        print_info "No se encontraron migraciones"
    fi
}

health_check() {
    print_info "Verificando salud de la aplicación..."
    
    if [ -n "$BACKEND_URL" ]; then
        if curl -f "$BACKEND_URL" > /dev/null 2>&1; then
            print_success "Backend respondiendo correctamente"
        else
            print_error "Backend no responde"
            return 1
        fi
    fi
    
    if [ -n "$FRONTEND_URL" ]; then
        if curl -f "$FRONTEND_URL" > /dev/null 2>&1; then
            print_success "Frontend respondiendo correctamente"
        else
            print_error "Frontend no responde"
            return 1
        fi
    fi
}

cleanup_old_backups() {
    print_info "Limpiando backups antiguos..."

    cd backups
    ls -t backup_code_*.tar.gz | tail -n +6 | xargs rm -f 2>/dev/null || true
    cd ..
    
    print_success "Limpieza completada"
}

main() {
    echo ""
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║                 SISTEMA ABARROTES                          ║"
    echo "╚════════════════════════════════════════════════════════════╝"
    echo ""

    check_environment
    load_env_file

    print_warning "¿Confirmar deployment de $COMPONENT a $ENVIRONMENT? (y/n)"
    read -r confirm
    if [ "$confirm" != "y" ]; then
        print_error "Deployment cancelado"
        exit 0
    fi

    create_backup

    if [ "$COMPONENT" = "backend" ] || [ "$COMPONENT" = "all" ]; then
        deploy_backend
    fi
    
    if [ "$COMPONENT" = "frontend" ] || [ "$COMPONENT" = "all" ]; then
        deploy_frontend
    fi

    if [ "$COMPONENT" = "all" ]; then
        run_database_migrations
    fi

    health_check

    cleanup_old_backups
    
    echo ""
    print_success "═══════════════════════════════════════════════════════════"
    print_success "   DEPLOYMENT COMPLETADO"
    print_success "   Ambiente: $ENVIRONMENT"
    print_success "   Componente: $COMPONENT"
    print_success "   Timestamp: $TIMESTAMP"
    print_success "═══════════════════════════════════════════════════════════"
    echo ""
}

main
